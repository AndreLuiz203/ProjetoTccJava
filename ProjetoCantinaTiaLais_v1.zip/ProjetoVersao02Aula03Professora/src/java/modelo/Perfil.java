/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author adm_pfelacio
 */
public class Perfil {
    
    private int idPerfil;
    private String nome;
    private int status;

    public Perfil() {
    }

    public Perfil(int idPerfil, String nome, int status) {
        this.idPerfil = idPerfil;
        this.nome = nome;
        this.status = status;
    }

    public int getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil) {
        this.idPerfil = idPerfil;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Perfil{" + "nome=" + nome + '}';
    }
    
    
    
}
