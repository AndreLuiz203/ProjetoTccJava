
package modelo;

public class Produtos {
    private int idProdutos;
    private String nome;
    private String quantidade;
    private int status;
    private Fornecedor fornecedor;

    public Produtos() {
    }

    public Produtos(int idProdutos, String nome, String quantidade, int status, Fornecedor fornecedor) {
        this.idProdutos = idProdutos;
        this.nome = nome;
        this.quantidade = quantidade;
        this.status = status;
        this.fornecedor = fornecedor;
    }

    public int getIdProdutos() {
        return idProdutos;
    }

    public void setIdProdutos(int idProdutos) {
        this.idProdutos = idProdutos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    @Override
    public String toString() {
        return "Produto{" + "idProdutos=" + idProdutos + ", nome=" + nome + ", quantidade=" + quantidade + ", status=" + status + ", fornecedor=" + fornecedor + '}';
    }
    
    
}
