
package modelo;

public class Fornecedores {
    private int idFornecedores;
    private String nomeRazaoSocial ;
    private String endereco;
    private String cpfCpnj;
    private String telefone;

    public Fornecedores() {
    }

    public Fornecedores(int idFornecedores, String nomeRazaoSocial, String endereco, String cpfCpnj, String telefone) {
        this.idFornecedores = idFornecedores;
        this.nomeRazaoSocial = nomeRazaoSocial;
        this.endereco = endereco;
        this.cpfCpnj = cpfCpnj;
        this.telefone = telefone;
        
    }

    public int getIdFornecedores() {
        return idFornecedores;
    }

    public void setIdFornecedores(int idFornecedores) {
        this.idFornecedores = idFornecedores;
    }

    public String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }

    public void setNomeRazaoSocial(String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }


    @Override
    public String toString() {
        return "Fornecedor{" + "idFornecedor=" + idFornecedores + ", nomeRazaoSocial=" + nomeRazaoSocial + ", endereco=" + endereco + ", telefone=" + telefone + '}';
    }
    
    
}
