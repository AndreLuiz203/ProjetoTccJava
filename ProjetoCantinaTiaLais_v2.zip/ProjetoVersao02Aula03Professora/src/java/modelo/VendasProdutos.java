package modelo;
public class VendasProdutos {
    private Vendas vendas;
    private Produtos produtos;
 
    public VendasProdutos() {
    }

    public VendasProdutos(Vendas vendas, Produtos produtos) {
        this.vendas = vendas;
        this.produtos = produtos;
    }

    public Vendas getVendas() {
        return vendas;
    }

    public void setVendas(Vendas vendas) {
        this.vendas = vendas;
    }

    public Produtos getProdutos() {
        return produtos;
    }

    public void setProdutos(Produtos produtos) {
        this.produtos = produtos;
    }

    @Override
    public String toString() {
        return "VendasProdutos{" + "vendas=" + vendas + ", produtos=" + produtos + '}';
    }
    
    
}
