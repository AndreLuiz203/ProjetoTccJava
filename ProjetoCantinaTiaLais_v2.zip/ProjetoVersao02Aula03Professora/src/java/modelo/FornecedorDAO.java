package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FornecedorDAO extends DataBaseDAO{
    public FornecedorDAO() throws ClassNotFoundException{}
    
    public ArrayList<Fornecedores> getLista(){
        
        ArrayList<Fornecedores> lista = new ArrayList<>();
        String sql = "SELECT * FROM fornecedor";
        
        try{
            //abre a conexao com o banco
            this.conectar();
            //Usando try-with-resources para PreparedStatement e ResultSet
            try(PreparedStatement pstm = conn.prepareStatement(sql);
                ResultSet rs = pstm.executeQuery()){
                
                while(rs.next()){
                    Fornecedores f = new Fornecedores();
                    f.setIdFornecedores(rs.getInt("idFornecedor"));
                    f.setNomeRazaoSocial(rs.getString("nome"));
                    f.setEndereco(rs.getString("endereco"));
                    f.setTelefone(rs.getString("telefone"));
                    f.setStatus(rs.getInt("status"));
                    lista.add(f);
                }
            }
        }catch(SQLException e){
            Logger.getLogger(FornecedorDAO.class.getName()).log(Level.SEVERE, null,e);
        }finally{
            this.desconectar();
        }
    
     return lista;
    }
    
    public boolean gravar(Fornecedores f){
        
        boolean sucesso = false;
        String sql;
        
        //define a query dependendo do IdFornecedor
        if(f.getIdFornecedores()==0){
            sql = "INSERT INTO fornecedor (nome, endereco, telefone, status) VALUES (?,?,?,?)";
        }else{
            sql = "UPDATE fornecedor SET nome=?, endereco=?, telefone=?, status=? WHERE idFornecedor=?";
        }
        try{
            this.conectar();
            //Usando try-with-resources para garantir fechamento do PreparedStatement
            try(PreparedStatement pstm = conn.prepareStatement(sql)){
                pstm.setString(1, f.getNomeRazaoSocial());
                pstm.setString(2, f.getEndereco());
                pstm.setString(3, f.getTelefone());
                pstm.setInt(4,f.getStatus());
                
                //verifica se o idFornecedor é maior que zero, se for realiza o UPDaTE
                if(f.getIdFornecedores()>0){
                    pstm.setInt(5, f.getIdFornecedores());
                }
                int rowsAffected = pstm.executeUpdate();
                if(rowsAffected > 0){
                    sucesso = true;// a operação foi bem sucedida
                }
                
            }
        }catch(SQLException e){
            Logger.getLogger(FornecedorDAO.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            this.desconectar();
        }
        return sucesso;
    
    }
    
    public Fornecedores getCarregaPorID(int idFornecedor){
        
        Fornecedores f =null;
        String sql = "SELECT * FROM fornecedor WHERE idFornecedor = ?";
        try{
            this.conectar();
            try(PreparedStatement pstm = conn.prepareStatement(sql)){
                pstm.setInt(1, idFornecedor);
                
                try(ResultSet rs = pstm.executeQuery()){
                    if(rs.next()){
                        f = new Fornecedores();
                        f.setIdFornecedores(rs.getInt("idFornecedor"));
                        f.setNomeRazaoSocial(rs.getString("nome"));
                        f.setEndereco(rs.getString("endereco"));
                        f.setTelefone(rs.getString("telefone"));
                        f.setStatus(rs.getInt("status"));
                        
                    }
                }
                
            }
            
        }catch(SQLException e){
            Logger.getLogger(FornecedorDAO.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            this.desconectar();
        }    
        return f;
    }
    
    public boolean excluir(Fornecedores f){
    
        boolean sucesso = false;
        try{
            this.conectar();
            String SQL = "DELETE FROM fornecedor WHERE idFornecedor=?";
            try(PreparedStatement pstm = conn.prepareStatement(SQL)){
                pstm.setInt(1, f.getIdFornecedores());
                int rowsffected = pstm.executeUpdate();
                if(rowsffected > 0){
                    sucesso = true;
                }
            }
        
        }catch(SQLException e){
            Logger.getLogger(FornecedorDAO.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            this.desconectar();
        }
        return sucesso;
    }
    
}
