package modelo;

public class Fornecedores {

    private int idFornecedores;
    private String nomeRazaoSocial;
    private String endereco;
    private String cpfCpnj;
    private String telefone;
    private int status;

   public Fornecedores() {
            }
    


   
    public int getIdFornecedores() {
        return idFornecedores;
    }

    public void setIdFornecedores(int idFornecedores) {
        this.idFornecedores = idFornecedores;
    }

    public String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }

    public void setNomeRazaoSocial(String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCpfCpnj() {
        return cpfCpnj;
    }

    public void setCpfCpnj(String cpfCpnj) {
        this.cpfCpnj = cpfCpnj;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Fornecedores(int idFornecedores, String nomeRazaoSocial, String endereco, String cpfCpnj, String telefone, int status) {
        this.idFornecedores = idFornecedores;
        this.nomeRazaoSocial = nomeRazaoSocial;
        this.endereco = endereco;
        this.cpfCpnj = cpfCpnj;
        this.telefone = telefone;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Fornecedores{" + "idFornecedores=" + idFornecedores + ", nomeRazaoSocial=" + nomeRazaoSocial + ", endereco=" + endereco + ", cpfCpnj=" + cpfCpnj + ", telefone=" + telefone + ", status=" + status + '}';
    }
}
