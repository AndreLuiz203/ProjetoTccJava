package modelo;

import java.util.Date;


public class Vendas {
    private int idVendas;
    private int total;
    private Date dataVenda;
    private Usuario usuario;

    public Vendas() {
    }

    public Vendas(int idVendas, int total, Date dataVenda, Usuario usuario) {
        this.idVendas = idVendas;
        this.total = total;
        this.dataVenda = dataVenda;
        this.usuario = usuario;
    }

    public int getIdVendas() {
        return idVendas;
    }

    public void setIdVendas(int idVendas) {
        this.idVendas = idVendas;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Vendas{" + "idVendas=" + idVendas + ", total=" + total + ", dataVenda=" + dataVenda + ", usuario=" + usuario + '}';
    }
    
    
}
